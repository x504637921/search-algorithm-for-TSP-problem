% this function is used for getting total distance of a path
function [pathlength] = Getpathlength(pathA,distance)
pathlength = 0;
L=length(pathA)-1;
for i=1:L
    pathlength = pathlength + distance(pathA(i),pathA(i+1)); %calculate the distance from the first city to the last city
end
pathlength=pathlength+distance(pathA(48),pathA(1));% calculate the distance for end ot end 
end
