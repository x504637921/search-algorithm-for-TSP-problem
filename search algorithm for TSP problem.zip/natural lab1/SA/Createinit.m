function now_way = Createinit(now_way)
vis = zeros(1,48);
for i = 1:48
    vis(i)=0;
end
a=1;
while a<=48
    b=ceil(rand()*48);
    if vis(b)==0
            vis(b)=1;
            now_way(a)=b;
            a=a+1;
    end
end                
end