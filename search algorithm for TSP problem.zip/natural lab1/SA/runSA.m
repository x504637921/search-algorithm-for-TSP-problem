% delete cache
 clear all;
 close all;
%init
% initial_temperature
T =4750;
% end_temperature
T_end =exp(-5); 
% iter in each temperature loop
L = 2000;
% learning rate
delta = 0.99;
filename = 'att48.tsp.txt';
fprintf('--------------------------------------------------------');
% read file 
%n is the number of citys 
%x is a martix to save x axes data
%y is a martix to save y axes data
%city_position is a martix to save x and y axes
[n,x,y,city_position] = Readfile(filename);
Clist =city_position; 
% calculate iter for each inner loop 
cnt=0;
% calculate number of cooling 
cnt2=0;
%  a martix which is used for save distance between city
distance=Getdistance(x,y);
% create a initial path which involve city number 1 to 48 
path = [1:48];
t = T;
%calculate running time of loop 
tic

while t>= T_end    
    % n iteration count to iterate the difference of objective function f. 
    %Therefore , optimal solution in each temperature can be obtained in advance. 
    for i1 = 1:L
        d1 = Getpathlength(path,distance); % generate total distance for the old path
        path_new = Changeposition(path);  % Randomly select two cities in the path for exchange and generate a new path
        d2 = Getpathlength(path_new,distance); % generate total distance for the new path
        de = d2 - d1;  %calculate the diffenece of this two path's total distances 
        if de<0        
            path = path_new; % accept new path 
        elseif exp(-de/t) > rand(1) %generate ramdom number from 0 to 1, apply Metropolis rules
            path = path_new;  % accept new path 
        end
        cnt =cnt+1;
    end
    t=t* delta; % cooling 
    cnt2 =cnt2+1;
    save_tem2(cnt2)= t;  %save every temperature in a matrix 
    save_cnt2(cnt2) = cnt2;
    result2 = Getpathlength(path,distance); %save every solution in a matrix
    save_result2(cnt2)= result2;
end
toc

disp('the best solution is')
result = Getpathlength(path,distance); 
disp(result)
% you can cancel comment if you want to look city road map
drawTSP(Clist,path,result,1);

%you can cancel comment if you want to get a relationship between iter and
%every solution
%  for i= 1: size(cnt2)
%  plot(save_cnt2(i,:),save_result2(i,:),'b','LineWidth',1);
%  xlabel('the number of iteration');ylabel('the value of best distance in each iteration');
%  end

%you can cancel comment if you want to get a relationship between each temperature and
%  for i= 1: size(save_cnt2)
%  plot(save_cnt2(i,:),save_tem2(i,:),'b','LineWidth',1);
%  end

%you can test if the calculating distances function is right 
%test good solution result = 10628
%pathA =[1,8,38,31,44,18,7,28,6,37,19,27,17,43,30,36,46,33,20,47,21,32,39,48,5,42,24,10,45,35,4,26,2,29,34,41,16,22,3,23,14,25,13,11,12,15,40,9];
%B=Getpathlength(pathA,distance);
%disp(B)