function newpathA = Changeposition(pathA)
%Use a random swap of the locations of two cities to generate a new route
%Randomly replace the coordinates of two different cities
i=floor(1+48*rand());
j=floor(1+48*rand());
newpathA = pathA;
    while i==j
        i=floor(1+48*rand());
        j=floor(1+48*rand());    
    end
% exchange the position
temp=newpathA(i);
newpathA(i) = newpathA(j);
newpathA(j) = temp;

end
