% get distance matrix
function d= Getdistance(x,y)
for i=1:48
    for j= i:48
        x0 = x(i)-x(j);
        y0 = y(i)-y(j);
        rij=sqrt((x0*x0+y0*y0)/10.0);
        tij = round(rij);
        if (tij<rij) 
            d(i,j) = tij+1;
            d(j,i)=d(i,j);
        else
            d(i,j)=tij;
            d(j,i)=d(i,j);
        end
    end
end
end

