% calculate the total distance for a path
function  path_length = Getpathlength(distance,population)
col = size(population,2); % get the number of cities in each route in the population 
path_length = 0;
for i=1:col-1
    path_length = path_length + distance(population(i),population(i+1));
end 
path_length=path_length+distance(population(48),population(1));
end

