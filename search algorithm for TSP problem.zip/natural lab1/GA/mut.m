%do mutation operation
function snnew=mut(snew,pm)  
  
bn=size(snew,2);  
snnew=snew;  
  
pmm=pro(pm);  %Decide whether to perform the cross operation according to the cross probability, 1 is yes, 0 is not 
if pmm==1  
    %randomly select middle cities in one path
   c1=mod(randi([65535]),48);    
   c2=mod(randi([65535]),48);  
   chb1=min(c1,c2);  
   chb2=max(c1,c2);  
   x=snew(chb1+1:chb2);  
   %Flip several cities in the middle of a path 
   snnew(chb1+1:chb2)=fliplr(x);  
end  
end  