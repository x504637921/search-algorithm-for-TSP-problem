%%Decide whether to perform the crossover(mutation) operation according to the cross probability, 1 is yes, 0 is not
%((rand()%100 + 0.0) / 100)
%The random number generated is less than the probability of mutation (crossover), then the individual will crossover (mutate)
%return a bool value pcc
function pcc=pro(pc)  
    test(1:100)=0;  
    l=round(100*pc);  
    test(1:l)=1;  
    n=round(rand*99)+1;  
    pcc=test(n);     
end  