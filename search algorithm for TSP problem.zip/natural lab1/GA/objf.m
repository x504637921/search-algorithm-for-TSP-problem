% get fitness value and individual cumulative probability
function [f,p]=objf(pop,distance)
%get the size of population
pop_size=size(pop,1); 
%initial a metrix f to save fitness value
f=zeros(pop_size,1);  
for i=1:pop_size  
   f(i)=Getpathlength(distance,pop(i,:));  
end  
%fitness value = reciprocal of total distance
f=1000./f';
  
%Calculate the probability of an individual being selected based on their fitness
fsum=0;  
for i=1:pop_size  
    %The better the fitness, the higher the probability of being selected
   fsum=fsum+f(i)^15;
end  
ps=zeros(pop_size,1);  
for i=1:pop_size  
   ps(i)=f(i)^15/fsum;  
end  
  
%calculate individual cumulative probability
p=zeros(pop_size,1);  
p(1)=ps(1);  
for i=2:pop_size  
   p(i)=p(i-1)+ps(i);  
end  
p=p';  
end  