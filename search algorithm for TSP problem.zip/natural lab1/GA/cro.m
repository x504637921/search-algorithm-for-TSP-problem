%crossover operation 
% s is population, seln is index of two path or two parent  ,pc is the probability of crossover
function scro=cro(s,seln,pc)  
 % get the  number of cities
bn=size(s,2);  
%Decide whether to perform the cross operation according to the cross probability, 1 is yes, 0 is not
%pcc is a boolean value
pcc=pro(pc);  
%select two path randomly in the population  
scro(1,:)=s(seln(1),:);  
scro(2,:)=s(seln(2),:); 
if pcc==1    
   c1=mod(randi([65535]),48);  %product a random city index 
   c2=mod(randi([65535]),48);  %product a random city index
   chb1=min(c1,c2);  
   chb2=max(c1,c2);  
   % Exchange the id of the middle cities between the two paths
   % then you can get two child
   middle=scro(1,chb1+1:chb2);  
   scro(1,chb1+1:chb2)=scro(2,chb1+1:chb2);  
   scro(2,chb1+1:chb2)=middle;  
   
   %After crossover ,if find there is a conflict that the index of middle cities is equal to the index of left cities  
   for i=1:chb1  
       while find(scro(1,chb1+1:chb2)==scro(1,i))  
           %find the index of citis in the middle cities which conflicts
           %with the left cities
           zhi=find(scro(1,chb1+1:chb2)==scro(1,i));  
           y=scro(2,chb1+zhi);  
           scro(1,i)=y;  
       end  
       while find(scro(2,chb1+1:chb2)==scro(2,i))  
           zhi=find(scro(2,chb1+1:chb2)==scro(2,i));  
           y=scro(1,chb1+zhi);  
           scro(2,i)=y;  
       end  
   end  
   for i=chb2+1:bn  
       while find(scro(1,1:chb2)==scro(1,i))  
           zhi=logical(scro(1,1:chb2)==scro(1,i));  
           y=scro(2,zhi);  
           scro(1,i)=y;  
       end  
       while find(scro(2,1:chb2)==scro(2,i))  
           zhi=logical(scro(2,1:chb2)==scro(2,i));  
           y=scro(1,zhi);  
           scro(2,i)=y;  
       end  
   end  
end  
end  