%Roulette selection
function seln=sel(p) 
seln=zeros(2,1);  
%Select two individuals from the population, preferably not the same individual twice
for i=1:2  
   %create a random number
   r=mod(randi([1,65535]),1000)/1000.0;    
   prand=p-r;  
   j=1;   
   %if random probability is less than cumulative probability,then select it
   while prand(j)<0  
       j=j+1;  
   end  
   seln(i)=j; %return the index of this selected individual 
   if i==2&&j==seln(i-1)    %%if these two index is same, we need to do selecting operation again
       r=rand; 
       prand=p-r;
       j=1;
       while prand(j)<0  
           j=j+1;  
       end  
   end  
end  
end  