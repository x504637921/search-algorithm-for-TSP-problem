clear all;
close all;

CityNum=48; 
pop_size=20; %initial population size 
gnmax=3000;  %iteration  
pc=0.9; %probability of crossover 
pm=0.3; %probability of mutation

filename = 'att48.tsp.txt'; 
[n,x,y,city_position] = Readfile(filename); %read files and get the number of cities, x axes, y axes and a metrix which saves city position
fprintf('---------------------------------------------------------\n');
distance=Getdistance(x,y); %get distance matrix
Clist =city_position;  
%create initial population
pop=zeros(pop_size,CityNum);  
%create initial ramdom route in each population
for i=1:pop_size  
    pop(i,:)=randperm(CityNum);  
end  
%calculate fitness value and Probability of individual selection  
% p is a matrix to save individual cumulative probability
[~,p]=objf(pop,distance); 
 
gn=1;  
ymean=zeros(gn,1);  
ymax=zeros(gn,1);  
xmax=zeros(pop_size,CityNum);  
scnew=zeros(pop_size,CityNum);  
smnew=zeros(pop_size,CityNum);
tic 
%start to run core of this algorithm
while gn<gnmax+1  
   for j=1:2:pop_size  
      seln=sel(p);  %select operation and get two parent,seln is the index of two parent in the population
      scro=cro(pop,seln,pc);  %crossover scro is index of two child 
      scnew(j,:)=scro(1,:);  %first child
      scnew(j+1,:)=scro(2,:);  % second child
      smnew(j,:)=mut(scnew(j,:),pm);  %mutate the child with a probability 
      smnew(j+1,:)=mut(scnew(j+1,:),pm);  %mutate the child with a probability 
   end  
   pop=smnew;  %create a new population
   [f,p]=objf(pop,distance);  %calculate the fitness value of new population
   %record the best fitness value 
   [fmax,nmax]=max(f);  
   ymean(gn)=1000/mean(f);  
   ymax(gn)=1000/fmax;  
   %recode the best individuals
   x=pop(nmax,:);  
   xmax(gn,:)=x;  
   %drawTSP(Clist,x,ymax(gn),gn,0);  
%    drawx(gn)= gn;
%    drawy(gn)=min(ymax);
   gn=gn+1;  
end
toc
%analysis data
% plot(drawx,drawy,'--r');
% xlabel('round')
% ylabel('number of population')
[min_ymax,index]=min(ymax);  
drawTSP(Clist,xmax(index,:),min_ymax,index,1);

fprintf('best distance is :%.2f\n',min_ymax);  
%output path
% fprintf('best route is ');  
% disp(xmax(index,:));  